let eventos = [
  { "capa": 1, "t": 0.0, "frecuencia": 130.81, "volumen": 0.6, "duracion": 0.8, "panoramica": -0.3 },
  { "capa": 2, "t": 0.5, "frecuencia": 293.66, "volumen": 0.5, "duracion": 0.4, "panoramica": -0.1 },
  { "capa": 3, "t": 1.0, "frecuencia": 523.25, "volumen": 0.7, "duracion": 1.2, "panoramica": 0.0 },
  { "capa": 4, "t": 1.5, "frecuencia": 329.63, "volumen": 0.4, "duracion": 0.6, "panoramica": 0.2 },
  { "capa": 5, "t": 2.0, "frecuencia": 1046.50, "volumen": 0.8, "duracion": 0.2, "panoramica": 0.3 }
];

let contexto = null;
let gananciaMaestra = null;
let pendientes = [];
let bucleTimer = null;
let capasActivas = [true, true, false, false, false];

function initAudio() {
  if (!contexto) {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    contexto = new AudioCtx();
    gananciaMaestra = contexto.createGain();
    gananciaMaestra.gain.value = 0.9;
    gananciaMaestra.connect(contexto.destination);
  }
  if (contexto.state === 'suspended') {
    contexto.resume();
  }
}

export async function cargarEventos(ruta = 'datos/eventos.json') {
  try {
    const url = new URL(`../${ruta}`, import.meta.url);
    const r = await fetch(url);
    if (r.ok) {
      const datos = await r.json();
      if (Array.isArray(datos) && datos.length > 0) {
        eventos = datos;
      }
    }
  } catch (err) {
    console.warn('Usando datos de prueba integrados:', err);
  }
  eventos.sort((a, b) => a.t - b.t);
  return eventos;
}

function disparar(e) {
  if (!capasActivas[e.capa - 1]) return;

  initAudio();

  const osc = contexto.createOscillator();
  const gan = contexto.createGain();

  // Onda 'triangle' para que los tonos graves y agudos se escuchen claros en cualquier laptop
  osc.type = 'triangle';
  osc.frequency.setValueAtTime(e.frecuencia, contexto.currentTime);

  const ahora = contexto.currentTime;
  const vol = Math.min(1, Math.max(0.25, e.volumen));
  gan.gain.setValueAtTime(0.001, ahora);
  gan.gain.linearRampToValueAtTime(vol, ahora + 0.03);
  gan.gain.exponentialRampToValueAtTime(0.001, ahora + e.duracion);

  osc.connect(gan);
  gan.connect(gananciaMaestra);

  osc.start(ahora);
  osc.stop(ahora + e.duracion + 0.05);

  window.dispatchEvent(new CustomEvent('jukebox:note', { detail: e }));
}

export function reproducirDesde(desde = 0) {
  initAudio();
  cancelarPendientes();

  if (eventos.length === 0) return;

  for (const e of eventos) {
    if (e.t < desde) continue;
    const espera = (e.t - desde) * 1000;
    pendientes.push(setTimeout(() => disparar(e), espera));
  }

  const ultimo = eventos[eventos.length - 1];
  const duracionCicloMs = ((ultimo.t + ultimo.duracion) - desde + 0.4) * 1000;
  bucleTimer = setTimeout(() => {
    reproducirDesde(0);
  }, Math.max(1000, duracionCicloMs));
}

export function cancelarPendientes() {
  for (const id of pendientes) clearTimeout(id);
  pendientes = [];
  if (bucleTimer) {
    clearTimeout(bucleTimer);
    bucleTimer = null;
  }
}

export function setCapaActiva(capa, activa) {
  capasActivas[capa - 1] = activa;
  // Si activas una capa mientras está sonando, dispara una vista previa inmediata de su tono
  if (activa && contexto && contexto.state === 'running') {
    const eventoCapa = eventos.find((ev) => ev.capa === capa);
    if (eventoCapa) disparar(eventoCapa);
  }
}

export function setVolumenMaestro(v) {
  if (gananciaMaestra) gananciaMaestra.gain.value = v;
}