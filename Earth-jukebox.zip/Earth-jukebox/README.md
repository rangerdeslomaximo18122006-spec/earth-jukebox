# Earth Jukebox

Plataforma web accesible para la sonificación de datos climáticos y terrestres de la NASA, diseñada para ser navegada al 100% mediante teclado y lectores de pantalla (NVDA).

## Arquitectura del Sistema

La interfaz de usuario (`feature/ui`) está desacoplada del motor de datos y audio mediante eventos nativos (`CustomEvent`):

- **`jukebox:playstate`**: Emitido al activar o pausar la reproducción (`event.detail.playing`: `true` / `false`).
- **`jukebox:layerchange`**: Emitido al alternar cualquiera de las 5 capas (`event.detail.id`: `'temp'`, `'co2'`, `'ice'`, `'sea'`, `'ndvi'`; `event.detail.enabled`: `boolean`).
- **Narrativa dinámica (`#live-description`)**: El motor de datos puede actualizar el texto de `#live-description` (`aria-live="polite"`) para que NVDA narre los cambios en tiempo real sin interrumpir el foco del usuario.

## Accesibilidad (WCAG 2.2 Nivel AA)

- **Navegación 100% por teclado:** Operable exclusivamente con `Tab`, `Shift + Tab`, `Enter` y `Espacio`.
- **Soporte para lectores de pantalla (NVDA):** HTML5 semántico, enlace de salto rápido (`skip-link`), `aria-pressed` y región dinámica `aria-live="polite"`.
- **Contraste verificado:** Paleta validada en WebAIM (> `11.9:1` AAA) y foco visible de `3px` en `#FBBF24`. Ver detalles en `docs/ACCESIBILIDAD.md`.

## Ejecución Local
No requiere compilación ni instalación de dependencias (`Tailwind CSS` se carga vía CDN):
1. Abrir `src/index.html` directamente en cualquier navegador moderno.