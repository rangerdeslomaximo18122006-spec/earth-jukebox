# Plan de Pruebas de UI, Teclado y Lector de Pantalla (NVDA)

## Prueba 1: Navegación exclusiva por teclado
1. Abrir `src/index.html` en el navegador sin tocar el mouse.
2. Presionar `Tab` (1ra vez): Debe aparecer el botón **"Saltar directamente al reproductor Jukebox"** en la esquina superior izquierda.
3. Presionar `Tab` (2da vez): El foco debe caer sobre **"Reproducir Sonificación"** con un borde amarillo visible.
4. Presionar `Espacio` o `Enter`: El texto del botón debe cambiar a **"Pausar Sonificación"** y la caja de *Descripción en Tiempo Real* debe actualizarse.
5. Presionar `Tab` (3ra a 7ma vez): El foco debe recorrer secuencialmente los 5 checkboxes de capas.
6. Presionar `Espacio` sobre cada checkbox: Debe marcar/desmarcar la casilla y actualizar el texto en `aria-live="polite"`.

## Prueba 2: Validación con NVDA
- [ ] Activar NVDA (`Ctrl + Alt + N`).
- [ ] Verificar que NVDA anuncia el título de la página y el rol de botón con estado (`no pulsado` / `pulsado`).
- [ ] Verificar que al marcar/desmarcar una capa, NVDA lee en voz alta el mensaje de `aria-live="polite"` sin interrumpir la navegación.