# Registro de Pruebas con NVDA (Sin Mouse)

## Pasos ejecutados
1. Iniciar NVDA (`Ctrl + Alt + N`).
2. Abrir `src/index.html` y navegar exclusivamente con `Tab`, `Shift + Tab`, `Enter` y `Espacio`.
3. Verificar lectura del enlace de salto, título, botón de reproducción (`no pulsado` / `pulsado`), región `aria-live` y los 5 checkboxes.

## Bugs encontrados y estado

| ID | Descripción del problema detectado con NVDA | Severidad | Estado |
| :--- | :--- | :--- | :--- |
| BUG-01 | *(Anotar aquí si NVDA no lee algún cambio o foco)* | Baja / Media / Alta | Pendiente |