# Auditoría y Checklist de Accesibilidad (WCAG 2.2 Nivel AA)

Este documento detalla los criterios de accesibilidad implementados en la interfaz de usuario (`src/index.html` y `src/css/styles.css`) de **Earth Jukebox**.

## 1. Perceptible
- [x] **1.1.1 Contenido no textual:** El elemento `<video>` está vinculado mediante `aria-describedby="live-description"` para ofrecer contexto textual continuo sobre la visualización.
- [x] **1.2.1 Solo audio y solo video:** La región dinámica `<div id="live-description" aria-live="polite">` anuncia en tiempo real el estado de reproducción y los cambios en las variables sonificadas.
- [x] **1.3.1 Información y relaciones:** Uso estricto de HTML5 semántico (`<header>`, `<main>`, `<section>`, `<aside>`, `<fieldset>`, `<legend>`) y etiquetas `<label>` vinculadas a cada control.
- [x] **1.4.3 Contraste (Mínimo):** Todos los textos cumplen y superan el ratio mínimo de 4.5:1 verificado mediante **WebAIM Contrast Checker**:
  - Texto principal (`#F1F5F9`) sobre fondo (`#020617`): **18.4:1 (AAA)**
  - Acentos y títulos (`#FBBF24`) sobre fondo (`#020617`): **11.9:1 (AAA)**
  - Texto de botón (`#020617`) sobre fondo ámbar (`#FBBF24`): **11.9:1 (AAA)**

## 2. Operable
- [x] **2.1.1 Teclado:** Operabilidad total sin mouse utilizando `Tab`, `Shift + Tab`, `Enter` y `Espacio`.
- [x] **2.1.2 Sin trampas para el foco:** El flujo de tabulación sigue el orden natural del DOM sin bloquear al usuario en ningún contenedor.
- [x] **2.4.1 Evitar bloques:** Enlace de salto rápido (`Saltar directamente al reproductor Jukebox`) disponible al presionar `Tab` al cargar la página.
- [x] **2.4.7 Foco visible / 2.4.11 Foco no oculto:** Anillo de enfoque sólido de `3px` en color `#FBBF24` con `outline-offset: 3px` en todos los elementos interactivos.
- [x] **2.5.8 Tamaño del objetivo (WCAG 2.2):** Todos los botones y áreas clicables de los checkboxes superan el mínimo de `24x24px`.

## 3. Comprensible
- [x] **3.1.1 Idioma de la página:** Declarado mediante `<html lang="es">` para la correcta pronunciación en lectores de pantalla como NVDA.
- [x] **3.2.2 Al recibir entradas:** Activar o desactivar cualquiera de las 5 capas sonoras actualiza el estado sin provocar cambios de contexto inesperados ni recargas.

## 4. Robusto
- [x] **4.1.2 Nombre, función, valor:** Uso de controles nativos (`<button>` con `aria-pressed` dinámico e `<input type="checkbox">`) que permiten a NVDA alternar automáticamente entre modo exploración y modo formulario.