# Checklist de Entrega — Earth Jukebox

## 1. Interfaz y Funcionalidad (`feature/ui`)
- [x] `src/index.html` estructurado con HTML5 semántico (`<header>`, `<main>`, `<section>`, `<aside>`).
- [x] Elemento `<video>` silenciado (`muted`) sincronizado sin interferir con el sintetizador.
- [x] Botón principal Play/Pausa con estado accesible (`aria-pressed`).
- [x] Cinco checkboxes funcionales para las capas de datos climáticos.
- [x] Región dinámica `<div aria-live="polite">` operativa para narración en tiempo real.
- [x] Tailwind CSS cargado por CDN sin dependencias de build.

## 2. Accesibilidad y Pruebas
- [x] Contraste de colores verificado con WebAIM (> 4.5:1).
- [x] Navegación completa sin mouse (`Tab`, `Enter`, `Espacio`).
- [x] Documentación WCAG 2.2 completada en `docs/ACCESIBILIDAD.md`.
- [ ] Prueba completa realizada con lector de pantalla **NVDA** (sin mouse) y bugs documentados en `tests/BUGS_NVDA.md`.
- [ ] Prueba grupal de accesibilidad de las 12:00 completada con todo el equipo.

## 3. Integración y Git
- [x] `README.md` actualizado con arquitectura de eventos y guía de accesibilidad.
- [ ] Rama `feature/ui` subida al repositorio remoto (`git push -u origin feature/ui`).